# Chrylics
Chrylics - Chrome extension to instantly view lyrics right next to the playing song.
Currently available when listening to songs on:
	1. YouTube.
	2. TuneIn Radio.

Instalation
==
Open a new tab and enter the following address in the URL: <br>
<b>chrome://extensions/</b>

Then simply drag the following crx file to chrome: <br>
https://github.com/ofekp/chrylics/blob/master/Versions/V1.1/Chrylics.crx?raw=true

Word of notice
==
Currently using AZLyrics (www.azlyrics.com).

Enjoy.
